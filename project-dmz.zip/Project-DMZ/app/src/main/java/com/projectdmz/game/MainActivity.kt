package com.projectdmz.game

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var game: GameSurface
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        val root = FrameLayout(this)
        game = GameSurface(this)
        root.addView(game)
        root.addView(HudView(this, game))
        setContentView(root)
    }
    override fun onPause() { super.onPause(); game.onPause() }
    override fun onResume() { super.onResume(); game.onResume() }
}

class HudView(ctx: android.content.Context, private val game: GameSurface) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var joyX=0f; private var joyY=0f; private var moving=false
    private var lookPointer=-1; private var lastX=0f; private var lastY=0f
    init { isFocusable = true }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        p.color=0x66000000; c.drawRoundRect(w*.30f,12f,w*.70f,86f,18f,18f,p)
        p.color=Color.WHITE; p.typeface=Typeface.DEFAULT_BOLD; p.textSize=23f
        c.drawText("DMZ  •  ${game.missionText}",w*.32f,40f,p)
        p.textSize=19f
        c.drawText("HP ${game.health}   ARMOR ${game.armor}   AMMO ${game.ammo}/${game.reserve}   KILLS ${game.kills}",w*.32f,69f,p)
        p.color=0x55000000; c.drawCircle(w*.15f,h*.78f,h*.14f,p)
        p.color=0xAAFFFFFF.toInt(); c.drawCircle(w*.15f+joyX*h*.09f,h*.78f+joyY*h*.09f,h*.045f,p)
        button(c,w*.86f,h*.78f,"FIRE",52f); button(c,w*.72f,h*.88f,"RELOAD",43f)
        button(c,w*.91f,h*.48f,"USE",40f); button(c,w*.78f,h*.64f,"AIM",38f)
        button(c,w*.90f,h*.90f,"MED",36f)
        p.color=0xCCFFFFFF.toInt(); c.drawCircle(w*.5f,h*.5f,3f,p)
        if(game.dead || game.extracted) {
            p.color=0xCC000000.toInt(); c.drawRect(0f,0f,w,h,p)
            p.color=Color.WHITE; p.textSize=42f
            val msg=if(game.extracted) "MISSION COMPLETE" else "OPERATOR DOWN"
            c.drawText(msg,w*.5f-p.measureText(msg)/2,h*.45f,p)
            p.textSize=22f
            val sub="KILLS ${game.kills}   LOOT ${game.lootCount}   TAP USE TO REDEPLOY"
            c.drawText(sub,w*.5f-p.measureText(sub)/2,h*.55f,p)
        }
    }
    private fun button(c:Canvas,x:Float,y:Float,s:String,r:Float) {
        p.color=0x77000000; c.drawCircle(x,y,r,p)
        p.color=Color.WHITE; p.textSize=16f; p.typeface=Typeface.DEFAULT_BOLD
        c.drawText(s,x-p.measureText(s)/2,y+6f,p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w=width.toFloat(); val h=height.toFloat()
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i=e.actionIndex; val x=e.getX(i); val y=e.getY(i)
                if(x<w*.32f && y>h*.48f) { moving=true; updateJoy(x,y) }
                else if(x>w*.82f && y>h*.62f && y<h*.85f) game.fire()
                else if(x>w*.64f && x<w*.84f && y>h*.76f) game.reload()
                else if(x>w*.84f && y<h*.62f) game.use()
                else if(x>w*.72f && y>h*.85f) game.heal()
                else if(x>w*.70f && y>h*.53f && y<h*.75f) game.aiming=true
                else { lookPointer=i; lastX=x; lastY=y }
            }
            MotionEvent.ACTION_MOVE -> {
                for(i in 0 until e.pointerCount) {
                    val x=e.getX(i); val y=e.getY(i)
                    if(moving && x<w*.36f) updateJoy(x,y)
                    if(e.getPointerId(i)==lookPointer) {
                        game.turn((x-lastX)*.0045f); game.pitch((y-lastY)*.0035f)
                        lastX=x; lastY=y
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if(e.getPointerId(e.actionIndex)==lookPointer) lookPointer=-1
                moving=false; joyX=0f; joyY=0f; game.move(0f,0f); game.aiming=false
                invalidate()
            }
        }
        invalidate()
        return true
    }
    private fun updateJoy(x:Float,y:Float) {
        joyX=max(-1f,min(1f,(x-width*.15f)/(height*.14f)))
        joyY=max(-1f,min(1f,(y-height*.78f)/(height*.14f)))
        game.move(joyX,joyY); invalidate()
    }
}
