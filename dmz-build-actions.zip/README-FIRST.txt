PROJECT DMZ — GITHUB ACTIONS PACKAGE

This package contains:
- build-dmz.zip: the Android game source archive
- .github/workflows/build.yml: GitHub Actions workflow to extract the ZIP and build a debug APK

IMPORTANT:
GitHub does not install/run a workflow just because a ZIP containing it is uploaded.
The workflow file must be present in the repository at exactly:
.github/workflows/build.yml

The game ZIP must be present in the repository root at exactly:
build-dmz.zip

Once both are committed to the main branch, open Actions and run "Build Project DMZ APK".
The APK will be available as the artifact named "project-dmz-debug-apk" when the workflow succeeds.

The source has not been compiled or tested on a physical Android device yet.
