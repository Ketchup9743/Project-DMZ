package com.projectdmz.game

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.*

data class Enemy(var x:Float,var z:Float,var hp:Int=3,var alive:Boolean=true)

class GameSurface(ctx: Context) : GLSurfaceView(ctx) {
    private val rendererGame = WorldRenderer()
    @Volatile var health=100
    @Volatile var ammo=30
    @Volatile var kills=0
    init { setEGLContextClientVersion(2); setRenderer(rendererGame); renderMode=RENDERMODE_CONTINUOUSLY }
    fun move(x:Float,y:Float) { rendererGame.mx=x; rendererGame.my=y }
    fun turn(v:Float) { rendererGame.yaw += v }
    fun pitch(v:Float) { rendererGame.pitch=(rendererGame.pitch+v).coerceIn(-.45f,.45f) }
    fun fire() { if(ammo<=0) return; ammo--; rendererGame.shoot() }
    fun reload() { ammo=30 }
    fun extract() { rendererGame.tryExtract() }
    override fun onTouchEvent(event: android.view.MotionEvent?) = false
    inner class WorldRenderer : Renderer {
        @Volatile var mx=0f; @Volatile var my=0f; @Volatile var yaw=0f; @Volatile var pitch=0f
        private var px=0f; private var pz=0f; private var program=0
        private var vp=FloatArray(16); private var proj=FloatArray(16); private var view=FloatArray(16)
        private var pos=FloatArray(3); private var color=FloatArray(4)
        private val enemies= mutableListOf(Enemy(3f,-10f),Enemy(-4f,-15f),Enemy(7f,-22f),Enemy(-8f,-25f),Enemy(1f,-32f))
        private var extracted=false
        private val cube= floatArrayOf(-.5f,-.5f,-.5f,.5f,-.5f,-.5f,.5f,.5f,-.5f,-.5f,.5f,-.5f,-.5f,-.5f,.5f,.5f,-.5f,.5f,.5f,.5f,.5f,-.5f,.5f,.5f)
        private val indices=byteArrayOf(0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,1,5,6,1,6,2,0,3,7,0,7,4)
        private lateinit var vb:FloatBuffer; private lateinit var ib:java.nio.ByteBuffer
        override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) {
            GLES20.glClearColor(.48f,.59f,.61f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            val vs="attribute vec3 a; uniform mat4 mvp; void main(){gl_Position=mvp*vec4(a,1.0);}"
            val fs="precision mediump float; uniform vec4 c; void main(){gl_FragColor=c;}"
            val v=shader(GLES20.GL_VERTEX_SHADER,vs); val f=shader(GLES20.GL_FRAGMENT_SHADER,fs)
            program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,v); GLES20.glAttachShader(program,f); GLES20.glLinkProgram(program)
            vb=ByteBuffer.allocateDirect(cube.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(cube).also{it.position(0)}
            ib=ByteBuffer.allocateDirect(indices.size).put(indices).also{it.position(0)}
        }
        private fun shader(type:Int,s:String):Int { val id=GLES20.glCreateShader(type); GLES20.glShaderSource(id,s); GLES20.glCompileShader(id); return id }
        override fun onSurfaceChanged(gl:javax.microedition.khronos.opengles.GL10?,w:Int,h:Int) { GLES20.glViewport(0,0,w,h); Matrix.frustumM(proj,0,-w.toFloat()/h,w.toFloat()/h,-1f,1f,1f,100f) }
        override fun onDrawFrame(gl:javax.microedition.khronos.opengles.GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            val dx=sin(yaw); val dz=-cos(yaw)
            px += (dx*my + cos(yaw)*mx)*.10f
            pz += (dz*my + sin(yaw)*mx)*.10f
            for(e in enemies) if(e.alive) {
                val vx=px-e.x; val vz=pz-e.z; val d=sqrt(vx*vx+vz*vz)
                if(d>1.2f) { e.x += vx/d*.018f; e.z += vz/d*.018f }
                if(d<2.0f) health=(health-1).coerceAtLeast(0)
            }
            val eyeX=px; val eyeY=1.65f; val eyeZ=pz
            Matrix.setLookAtM(view,0,eyeX,eyeY,eyeZ,eyeX+dx,eyeY+pitch,eyeZ+dz,0f,1f,0f)
            Matrix.multiplyMM(vp,0,proj,0,view,0)
            drawBox(0f,-.6f,-18f,45f,.2f,60f,.30f,.36f,.32f)
            // scattered cover, buildings and extraction marker
            for(i in -3..3) drawBox(i*5f,1f,-18f,2.5f,2f,2f,.42f,.43f,.40f)
            drawBox(0f,1.2f,-35f,8f,2.4f,8f,.48f,.43f,.34f)
            drawBox(12f,1.4f,-25f,5f,2.8f,5f,.38f,.42f,.39f)
            drawBox(-13f,1.2f,-31f,6f,2.4f,6f,.46f,.40f,.32f)
            drawBox(0f,.05f,-8f,3f,.1f,3f,if(extracted) .1f else .1f,if(extracted) .8f else .65f,.15f)
            for(e in enemies) if(e.alive) drawBox(e.x,1f,e.z,.8f,2f,.8f,.48f,.16f,.12f)
        }
        private fun drawBox(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float) {
            val model=FloatArray(16); val mvp=FloatArray(16)
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz)
            Matrix.multiplyMM(mvp,0,vp,0,model,0)
            GLES20.glUseProgram(program)
            val a=GLES20.glGetAttribLocation(program,"a"); val u=GLES20.glGetUniformLocation(program,"mvp"); val c=GLES20.glGetUniformLocation(program,"c")
            GLES20.glUniformMatrix4fv(u,1,false,mvp,0); GLES20.glUniform4f(c,r,g,b,1f)
            GLES20.glEnableVertexAttribArray(a); GLES20.glVertexAttribPointer(a,3,GLES20.GL_FLOAT,false,0,vb)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES,indices.size,GLES20.GL_UNSIGNED_BYTE,ib); GLES20.glDisableVertexAttribArray(a)
        }
        fun shoot() {
            val dx=sin(yaw); val dz=-cos(yaw)
            val target=enemies.filter{it.alive}.map{e-> Pair(e, (e.x-px)*dx+(e.z-pz)*dz) }
                .filter{it.second>0 && abs((it.first.x-px)*dz-(it.first.z-pz)*dx)<1.8f}
                .minByOrNull{it.second}
            if(target!=null && target.second<35f) { target.first.hp--; if(target.first.hp<=0){target.first.alive=false; kills++} }
        }
        fun tryExtract() { if(sqrt(px*px+(pz+8f)*(pz+8f))<5f) extracted=true }
    }
}
