# Project DMZ — Android playable prototype (0.1)

This is an early, original, offline Android FPS prototype. It is a foundation, not the full planned DMZ-scale game.

## Included
- Landscape Android app using Kotlin + OpenGL ES 2.0 (no Unity)
- First-person camera, touch look and left-side movement joystick
- Fire/reload controls, ammo and kill counter
- Basic enemies that move toward the player and deal contact damage
- Simple desert-colored greybox map, cover and an extraction marker
- GitHub Actions workflow to build a debug APK

## Build on GitHub from an Android phone
1. Open your repository in Chrome and choose **Add file → Upload files**.
2. Upload the contents of this ZIP (not the ZIP file itself), keeping the folder structure.
3. Commit to `main`.
4. Open the repository's **Actions** tab and select **Build Android APK**.
5. Tap **Run workflow** (or wait for the push build).
6. Open the completed run and download the `project-dmz-debug-apk` artifact.

## Controls
- Left joystick: move
- Drag the right side: look/aim
- FIRE: shoot
- RELOAD: refill the prototype magazine
- EXTRACT: attempt extraction near the green pad

## Important
- The project has not been compiled or device-tested in this environment.
- This prototype deliberately uses simple original geometric graphics and placeholder behavior.
- Inventory, stash, squad commands, multiple maps, full weapon handling, save system, missions, vehicles, and polished art are later milestones.
