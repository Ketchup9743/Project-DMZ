# Project DMZ — playable offline mission build (0.2)

An expanded Android-native first-person extraction-shooter prototype. Built with Kotlin and OpenGL ES 2.0; no Unity required.

## Playable systems in this build
- Landscape full-screen Android app
- First-person camera, left movement joystick and right-side touch look
- Aim mode, firing, magazine/reserve ammo and reload
- Eight hostile AI soldiers that pursue and damage the player
- Health and armor, two-use medkit supply
- Loot pickups: ammunition and armor
- Elimination objective and extraction zone
- Mission success and operator-down states, with redeploy/reset
- Larger desert/industrial training area with buildings, cover and loot markers
- Entirely offline; no account or network connection required

## Controls
- Left joystick: move
- Drag right side: look
- FIRE: shoot
- AIM: tighter shot alignment while aiming
- RELOAD: reload from reserve ammunition
- USE: collect nearby loot; extract at the green zone after all enemies are eliminated
- MED: use a medkit

## Build on GitHub from an Android phone
1. Upload the contents of this ZIP to the repository, preserving the `Project-DMZ/` folder structure.
2. Commit to `main` and let the Actions workflow build.
3. Download the `project-dmz-debug-apk` artifact from the successful workflow run.
4. Extract the artifact ZIP and install the APK.

## Honest scope
This is a playable vertical-slice mission, not the finished DMZ-scale game. The planned ten maps, polished 3D character/weapon assets, full lobby, persistent stash/economy, squad commands, vehicles, factions, safehouse, advanced missions and dynamic events are not yet implemented. They remain future development work. This source has not been compiled or device-tested in this session; validate it through the repository's Android build workflow before installing.
