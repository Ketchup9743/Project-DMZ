package com.projectdmz.game

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.*

data class Enemy(var x:Float,var z:Float,var hp:Int=4,var alive:Boolean=true,var cooldown:Int=0)
data class Loot(var x:Float,var z:Float,var kind:Int,var taken:Boolean=false)

class GameSurface(ctx: Context) : GLSurfaceView(ctx) {
    private val world=WorldRenderer()
    @Volatile var health=100
    @Volatile var armor=50
    @Volatile var ammo=30
    @Volatile var reserve=120
    @Volatile var kills=0
    @Volatile var lootCount=0
    @Volatile var dead=false
    @Volatile var extracted=false
    @Volatile var aiming=false
    @Volatile var missionText="ELIMINATE HOSTILES • LOOT • EXTRACT"
    init { setEGLContextClientVersion(2); setRenderer(world); renderMode=RENDERMODE_CONTINUOUSLY }
    fun move(x:Float,y:Float) { world.mx=x; world.my=y }
    fun turn(v:Float) { world.yaw+=v }
    fun pitch(v:Float) { world.pitch=(world.pitch+v).coerceIn(-.55f,.55f) }
    fun fire() { if(dead||extracted)return; if(ammo>0){ammo--;world.shoot()} }
    fun reload() { if(dead||extracted||ammo>=30||reserve<=0)return; val n=min(30-ammo,reserve);ammo+=n;reserve-=n }
    fun heal() { if(dead||extracted||world.medkits<=0||health>=100)return;world.medkits--;health=min(100,health+45) }
    fun use() {
        if(dead||extracted){ world.reset();health=100;armor=50;ammo=30;reserve=120;kills=0;lootCount=0;dead=false;extracted=false;missionText="ELIMINATE HOSTILES • LOOT • EXTRACT";return }
        world.interact()
    }
    inner class WorldRenderer : Renderer {
        @Volatile var mx=0f; @Volatile var my=0f; @Volatile var yaw=0f; @Volatile var pitch=0f
        private var px=0f; private var pz=0f; private var program=0
        private val vp=FloatArray(16); private val proj=FloatArray(16); private val view=FloatArray(16)
        private val cube=floatArrayOf(-.5f,-.5f,-.5f,.5f,-.5f,-.5f,.5f,.5f,-.5f,-.5f,.5f,-.5f,-.5f,-.5f,.5f,.5f,-.5f,.5f,.5f,.5f,.5f,-.5f,.5f,.5f)
        private val indices=byteArrayOf(0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,1,5,6,1,6,2,0,3,7,0,7,4)
        private lateinit var vb:FloatBuffer; private lateinit var ib:ByteBuffer
        val enemies= mutableListOf<Enemy>()
        val loot= mutableListOf<Loot>()
        var medkits=2
        private var frame=0
        init { reset() }
        fun reset(){px=0f;pz=0f;yaw=0f;pitch=0f;enemies.clear();loot.clear();medkits=2
            val positions=listOf(3f to -12f,-5f to -19f,8f to -27f,-10f to -34f,2f to -43f,14f to -48f,-16f to -52f,0f to -60f)
            positions.forEach{enemies.add(Enemy(it.first,it.second))}
            loot.addAll(listOf(Loot(2f,-7f,0),Loot(-4f,-22f,1),Loot(7f,-37f,0),Loot(-8f,-46f,1)))
        }
        override fun onSurfaceCreated(gl:javax.microedition.khronos.opengles.GL10?,config:javax.microedition.khronos.egl.EGLConfig?){
            GLES20.glClearColor(.48f,.57f,.55f,1f);GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            val vs="attribute vec3 a; uniform mat4 mvp; void main(){gl_Position=mvp*vec4(a,1.0);}"
            val fs="precision mediump float; uniform vec4 c; void main(){gl_FragColor=c;}"
            val v=shader(GLES20.GL_VERTEX_SHADER,vs);val f=shader(GLES20.GL_FRAGMENT_SHADER,fs)
            program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program)
            vb=ByteBuffer.allocateDirect(cube.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(cube).also{it.position(0)}
            ib=ByteBuffer.allocateDirect(indices.size).order(ByteOrder.nativeOrder()).put(indices).also{it.position(0)}
        }
        private fun shader(t:Int,s:String):Int{val id=GLES20.glCreateShader(t);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);return id}
        override fun onSurfaceChanged(gl:javax.microedition.khronos.opengles.GL10?,w:Int,h:Int){GLES20.glViewport(0,0,w,h);val a=w.toFloat()/max(1,h);Matrix.frustumM(proj,0,-a,a,-1f,1f,1f,120f)}
        override fun onDrawFrame(gl:javax.microedition.khronos.opengles.GL10?){
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            frame++
            if(!dead&&!extracted){
                val speed=if(aiming).055f else .085f
                val dx=sin(yaw);val dz=-cos(yaw)
                px+=(dx*my+cos(yaw)*mx)*speed;pz+=(dz*my+sin(yaw)*mx)*speed
                px=px.coerceIn(-22f,22f);pz=pz.coerceIn(-75f,4f)
                enemies.filter{it.alive}.forEach{e->
                    val vx=px-e.x;val vz=pz-e.z;val d=sqrt(vx*vx+vz*vz)
                    if(d>1.6f){e.x+=vx/d*.018f;e.z+=vz/d*.018f}
                    else if(frame%35==0){if(armor>0)armor=(armor-5).coerceAtLeast(0) else health=(health-7).coerceAtLeast(0)}
                }
                if(health<=0)dead=true
            }
            val dx=sin(yaw);val dz=-cos(yaw)
            Matrix.setLookAtM(view,0,px,1.65f,pz,px+dx,1.65f+pitch,pz+dz,0f,1f,0f)
            Matrix.multiplyMM(vp,0,proj,0,view,0)
            drawBox(0f,-.65f,-35f,55f,.25f,90f,.34f,.36f,.32f)
            // roads, walls, industrial sheds and scattered cover
            for(i in -2..2) drawBox(i*10f,1f,-24f,1.5f,2f,70f,.28f,.30f,.27f)
            for(i in -3..3){drawBox(i*7f,1.4f,-18f,4f,2.8f,4f,.43f,.40f,.33f);drawBox(i*8f,1.8f,-43f,5f,3.6f,6f,.38f,.40f,.37f)}
            drawBox(0f,.05f,-8f,5f,.1f,5f,.08f,.75f,.18f)
            drawBox(0f,1f,-8f,5f,2f,.15f,.1f,.55f,.15f)
            enemies.filter{it.alive}.forEach{e->
                drawBox(e.x,.65f,e.z,.65f,1.3f,.5f,.20f,.25f,.20f)
                drawBox(e.x,1.45f,e.z,.38f,.38f,.38f,.55f,.42f,.32f)
            }
            loot.filter{!it.taken}.forEach{l->drawBox(l.x,.25f,l.z,.65f,.45f,.65f,if(l.kind==0).75f else .15f,if(l.kind==0).62f else .55f,.12f)}
            drawBox(0f,.04f,-70f,6f,.12f,6f,.1f,.8f,.18f)
        }
        private fun drawBox(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float){
            val model=FloatArray(16);val mvp=FloatArray(16);Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz);Matrix.multiplyMM(mvp,0,vp,0,model,0)
            GLES20.glUseProgram(program);val a=GLES20.glGetAttribLocation(program,"a");val u=GLES20.glGetUniformLocation(program,"mvp");val c=GLES20.glGetUniformLocation(program,"c")
            GLES20.glUniformMatrix4fv(u,1,false,mvp,0);GLES20.glUniform4f(c,r,g,b,1f);GLES20.glEnableVertexAttribArray(a);GLES20.glVertexAttribPointer(a,3,GLES20.GL_FLOAT,false,0,vb);GLES20.glDrawElements(GLES20.GL_TRIANGLES,indices.size,GLES20.GL_UNSIGNED_BYTE,ib);GLES20.glDisableVertexAttribArray(a)
        }
        fun shoot(){
            val dx=sin(yaw);val dz=-cos(yaw)
            val target=enemies.filter{it.alive}.map{e->Pair(e,(e.x-px)*dx+(e.z-pz)*dz)}
                .filter{it.second>0&&abs((it.first.x-px)*dz-(it.first.z-pz)*dx)<(if(aiming).8f else 1.5f)}
                .minByOrNull{it.second}
            if(target!=null&&target.second<45f){target.first.hp--;if(target.first.hp<=0){target.first.alive=false;kills++}}
        }
        fun interact(){
            val item=loot.filter{!it.taken}.minByOrNull{sqrt((it.x-px)*(it.x-px)+(it.z-pz)*(it.z-pz))}
            if(item!=null&&sqrt((item.x-px)*(item.x-px)+(item.z-pz)*(item.z-pz))<4f){item.taken=true;lootCount++;if(item.kind==0)reserve+=30 else armor=min(100,armor+25);return}
            if(sqrt(px*px+(pz+70f)*(pz+70f))<7f&&enemies.none{it.alive}){extracted=true;missionText="EXTRACTION SUCCESSFUL"}
        }
    }
}
