package com.projectdmz.game

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var game: GameSurface
    private lateinit var hud: HudView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        val root = FrameLayout(this)
        game = GameSurface(this)
        hud = HudView(this, game)
        root.addView(game)
        root.addView(hud)
        setContentView(root)
    }
    override fun onPause() { super.onPause(); game.onPause() }
    override fun onResume() { super.onResume(); game.onResume() }
}

class HudView(ctx: android.content.Context, private val game: GameSurface) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var joyX = 0f; private var joyY = 0f; private var active = false
    private var lookX = 0f; private var lookY = 0f; private var lookActive = false
    private var lastX = 0f; private var lastY = 0f
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        p.color=0x55000000; c.drawCircle(w*.15f,h*.78f, h*.14f,p)
        p.color=0x88FFFFFF.toInt(); c.drawCircle(w*.15f+joyX*h*.09f,h*.78f+joyY*h*.09f,h*.045f,p)
        button(c,w*.86f,h*.78f,"FIRE"); button(c,w*.72f,h*.88f,"RELOAD")
        button(c,w*.90f,h*.45f,"EXTRACT"); button(c,w*.10f,h*.16f,"DMZ")
        p.color=Color.WHITE; p.textSize=28f; p.typeface=Typeface.DEFAULT_BOLD
        c.drawText("HP ${game.health}   AMMO ${game.ammo}/30   KILLS ${game.kills}",w*.34f,42f,p)
        p.textSize=19f; p.drawText("Find the extraction zone",w*.40f,72f,p)
        p.color=0xCCFFFFFF.toInt(); c.drawCircle(w*.5f,h*.5f,3f,p)
    }
    private fun button(c:Canvas,x:Float,y:Float,s:String) {
        p.color=0x66000000; c.drawCircle(x,y,48f,p)
        p.color=Color.WHITE; p.textSize=18f; p.typeface=Typeface.DEFAULT_BOLD
        c.drawText(s,x-p.measureText(s)/2,y+6f,p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w=width.toFloat(); val h=height.toFloat()
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i=e.actionIndex; val x=e.getX(i); val y=e.getY(i)
                if(x<w*.32f && y>h*.48f) { active=true; updateJoy(x,y) }
                else if(x>w*.80f && y>h*.58f) game.fire()
                else if(x>w*.65f && y>h*.78f) game.reload()
                else if(x>w*.84f && y<h*.62f) game.extract()
                else { lookActive=true; lastX=x; lastY=y }
            }
            MotionEvent.ACTION_MOVE -> {
                for(i in 0 until e.pointerCount) {
                    val x=e.getX(i); val y=e.getY(i)
                    if(x<w*.34f && active) updateJoy(x,y)
                    else if(lookActive) {
                        game.turn((x-lastX)*.004f); game.pitch((y-lastY)*.003f)
                        lastX=x; lastY=y
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                active=false; joyX=0f; joyY=0f; lookActive=false; game.move(0f,0f); invalidate()
            }
        }
        return true
    }
    private fun updateJoy(x:Float,y:Float) {
        joyX=max(-1f,min(1f,(x-width*.15f)/(height*.14f)))
        joyY=max(-1f,min(1f,(y-height*.78f)/(height*.14f)))
        game.move(joyX,joyY); invalidate()
    }
}
